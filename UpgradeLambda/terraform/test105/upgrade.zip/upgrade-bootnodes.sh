#!/bin/bash
# bootnodes

. ./upgrade-constellation.sh
. ./upgrade-consul.sh
. ./upgrade-bootnode.sh

