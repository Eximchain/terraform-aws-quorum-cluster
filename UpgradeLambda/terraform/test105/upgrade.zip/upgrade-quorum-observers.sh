#!/bin/bash
# quorum-observers

. ./upgrade-blockmetrics.sh
. ./upgrade-cloudwatchmetrics.sh
. ./upgrade-constellation.sh
. ./upgrade-consul.sh
. ./upgrade-crashconstellation.sh
. ./upgrade-crashquorum.sh
. ./upgrade-quorum.sh
