#!/bin/bash
# vault servers

. ./upgrade-consul.sh
. ./upgrade-vault.sh
