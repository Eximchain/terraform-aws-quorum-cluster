#!/bin/bash
# quorum-makers

. ./upgrade-blockmetrics.sh
. ./upgrade-consul.sh
. ./upgrade-constellation.sh
. ./upgrade-quorum.sh
